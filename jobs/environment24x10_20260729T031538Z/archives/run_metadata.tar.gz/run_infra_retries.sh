#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

has_complete_results() {
  local config="$1"
  python3 - "$config" <<'PY'
import json
import sys
from pathlib import Path

config_path = Path(sys.argv[1])
data = json.loads(config_path.read_text(encoding="utf-8"))
expected = set(data["datasets"][0]["task_names"])
jobs = Path(data["jobs_dir"])
verified = set()
for path in jobs.glob("*/*/result.json"):
    result = json.loads(path.read_text(encoding="utf-8"))
    task = (result.get("task_name") or "").rsplit("/", 1)[-1]
    reward = (
        ((result.get("verifier_result") or {}).get("rewards") or {}).get(
            "reward"
        )
    )
    if reward is not None:
        verified.add(task)
sys.exit(0 if expected <= verified else 1)
PY
}

for config in "$root"/configs_path_fix_retries/*.json; do
  name="$(basename "${config%.json}")"
  log="$root/launcher_logs_path_fix_retries/$name.log"
  status="$root/launcher_logs_path_fix_retries/$name.status"

  printf 'started_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$status"
  : > "$log"
  completed=false
  for attempt in 1 2 3; do
    printf 'attempt_%s_started_at=%s\n' \
      "$attempt" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
    printf '\n===== attempt %s =====\n' "$attempt" >> "$log"
    if PYTHONPATH="$root${PYTHONPATH:+:$PYTHONPATH}" \
      harbor run --config "$config" --yes >> "$log" 2>&1; then
      code=0
    else
      code=$?
    fi
    printf 'attempt_%s_exit_code=%s\n' "$attempt" "$code" >> "$status"
    if has_complete_results "$config"; then
      completed=true
      break
    fi
  done
  if [ "$completed" != true ]; then
    printf 'exit_code=1\nfinished_at=%s\n' \
      "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
    exit 1
  fi
  printf 'exit_code=0\nfinished_at=%s\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
done
