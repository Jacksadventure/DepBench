#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mapfile -t configs < <(find "$root/configs" -maxdepth 1 -type f -name '*.json' -printf '%f\n' | sort)
max_active=5

run_config() {
  local file="$1"
  local name="${file%.json}"
  local log="$root/launcher_logs/$name.log"
  local status="$root/launcher_logs/$name.status"

  printf 'started_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$status"
  if PYTHONPATH="$root${PYTHONPATH:+:$PYTHONPATH}" harbor run --config "$root/configs/$file" --yes > "$log" 2>&1; then
    printf 'exit_code=0\nfinished_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
  else
    local code=$?
    printf 'exit_code=%s\nfinished_at=%s\n' "$code" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
    return "$code"
  fi
}

pids=()
names=()
failures=0

for file in "${configs[@]}"; do
  while ((${#pids[@]} >= max_active)); do
    if wait "${pids[0]}"; then
      printf 'completed %s\n' "${names[0]}"
    else
      printf 'failed %s\n' "${names[0]}" >&2
      failures=$((failures + 1))
    fi
    pids=("${pids[@]:1}")
    names=("${names[@]:1}")
  done

  run_config "$file" &
  pids+=("$!")
  names+=("${file%.json}")
  printf 'launched %s\n' "${file%.json}"
done

for index in "${!pids[@]}"; do
  if wait "${pids[$index]}"; then
    printf 'completed %s\n' "${names[$index]}"
  else
    printf 'failed %s\n' "${names[$index]}" >&2
    failures=$((failures + 1))
  fi
done

if ((failures > 0)); then
  printf '%s configuration(s) failed\n' "$failures" >&2
  exit 1
fi
