#!/usr/bin/env python3

import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
LOG_FILES = (
    "agent/claude-code.txt",
    "agent/codex.txt",
    "agent/copilot-cli.jsonl",
    "agent/copilot-cli.txt",
    "agent/opencode.txt",
    "verifier/test-stdout.txt",
    "verifier/test-stderr.txt",
)
PATTERNS = {
    tool: (
        f"{tool}: command not found".encode(),
        f"{tool}: not found".encode(),
        f"no such file or directory: '{tool}'".encode(),
        f'executable file not found in $path: {tool}'.encode(),
    )
    for tool in ("cargo", "rustc", "mvn", "java", "go", "gofmt")
}
PATTERNS["xlib_header"] = (
    b"x11/xlib.h: no such file or directory",
)


def missing_tools(trial: Path) -> list[str]:
    found = set()
    for name in LOG_FILES:
        path = trial / name
        if not path.is_file():
            continue
        payload = path.read_bytes().lower()
        for tool, patterns in PATTERNS.items():
            if tool not in found and any(
                pattern in payload for pattern in patterns
            ):
                found.add(tool)
    return sorted(found)


def main() -> int:
    rows = []
    for jobs_directory in (
        "harbor_jobs",
        "harbor_jobs_path_fix",
        "harbor_jobs_path_fix_retries",
    ):
        root = ROOT / jobs_directory
        if not root.is_dir():
            continue
        for result_path in sorted(root.glob("*/*/*/result.json")):
            trial = result_path.parent
            tools = missing_tools(trial)
            if not tools:
                continue
            result = json.loads(result_path.read_text(encoding="utf-8"))
            rows.append(
                {
                    "config": result_path.parts[-4],
                    "task": str(result.get("task_name") or "").split("/")[-1],
                    "trial": trial.name,
                    "source": jobs_directory,
                    "missing_tools": ",".join(tools),
                    "path": str(result_path.relative_to(ROOT)),
                }
            )

    output = ROOT / "analysis/toolchain_path_failures.csv"
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "config",
                "task",
                "trial",
                "source",
                "missing_tools",
                "path",
            ],
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)
    print(f"found {len(rows)} trials with missing toolchain commands")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
