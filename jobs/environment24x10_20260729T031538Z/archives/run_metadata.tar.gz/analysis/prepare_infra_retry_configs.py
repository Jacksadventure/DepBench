#!/usr/bin/env python3

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RETRYABLE_EXCEPTIONS = {
    "AgentSetupTimeoutError",
    "NonZeroAgentExitCodeError",
}


def completed_results(configuration):
    return sorted(
        (
            ROOT / "harbor_jobs_path_fix" / configuration
        ).glob("*/*/result.json")
    )


def main():
    output = ROOT / "configs_path_fix_retries"
    jobs = ROOT / "harbor_jobs_path_fix_retries"
    logs = ROOT / "launcher_logs_path_fix_retries"
    output.mkdir(parents=True, exist_ok=True)
    for path in (jobs, logs):
        if path.exists() and any(path.iterdir()):
            raise SystemExit(f"refusing to reuse non-empty directory: {path}")
        path.mkdir(parents=True, exist_ok=True)

    retry_cells = []
    for source in sorted((ROOT / "configs_path_fix").glob("*.json")):
        configuration = source.stem
        tasks = []
        for result_path in completed_results(configuration):
            result = json.loads(result_path.read_text(encoding="utf-8"))
            exception_type = (result.get("exception_info") or {}).get(
                "exception_type"
            )
            reward = (
                (
                    (result.get("verifier_result") or {}).get("rewards")
                    or {}
                ).get("reward")
            )
            if (
                reward is not None
                or exception_type not in RETRYABLE_EXCEPTIONS
            ):
                continue
            task = (result.get("task_name") or "").rsplit("/", 1)[-1]
            if not task:
                raise SystemExit(f"{result_path}: missing task_name")
            tasks.append(task)
            retry_cells.append(
                {
                    "configuration": configuration,
                    "task": task,
                    "exception_type": exception_type,
                    "replaced_result": str(result_path.relative_to(ROOT)),
                }
            )
        if not tasks:
            continue
        if len(tasks) != len(set(tasks)):
            raise SystemExit(f"{configuration}: duplicate retry tasks")

        data = json.loads(source.read_text(encoding="utf-8"))
        data["datasets"][0]["task_names"] = sorted(tasks)
        data["jobs_dir"] = str(jobs / configuration)
        data["n_concurrent_trials"] = 4
        data["agents"][0]["override_setup_timeout_sec"] = 900
        destination = output / source.name
        destination.write_text(
            json.dumps(data, indent=2) + "\n",
            encoding="utf-8",
        )

    expected_config_files = {
        f"{row['configuration']}.json" for row in retry_cells
    }
    observed_config_files = {
        path.name for path in output.glob("*.json")
    }
    if observed_config_files != expected_config_files:
        raise SystemExit(
            "stale retry configuration files are present: "
            f"{sorted(observed_config_files ^ expected_config_files)}"
        )

    manifest = {
        "retryable_exceptions": sorted(RETRYABLE_EXCEPTIONS),
        "cells": sorted(
            retry_cells,
            key=lambda row: (row["configuration"], row["task"]),
        ),
    }
    (ROOT / "manifests" / "infra_retry_cells.json").write_text(
        json.dumps(manifest, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        f"prepared {len(retry_cells)} retry cells across "
        f"{len(list(output.glob('*.json')))} configurations"
    )


if __name__ == "__main__":
    main()
