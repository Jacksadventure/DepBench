#!/usr/bin/env python3

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    output = ROOT / "configs_path_fix"
    jobs = ROOT / "harbor_jobs_path_fix"
    logs = ROOT / "launcher_logs_path_fix"
    for path in (output, jobs, logs):
        if path.exists() and any(path.iterdir()):
            raise SystemExit(f"refusing to reuse non-empty directory: {path}")
        path.mkdir(parents=True, exist_ok=True)

    for source in sorted((ROOT / "configs").glob("*.json")):
        data = json.loads(source.read_text(encoding="utf-8"))
        configuration = source.stem
        data["jobs_dir"] = str(jobs / configuration)
        destination = output / source.name
        destination.write_text(
            json.dumps(data, indent=2) + "\n",
            encoding="utf-8",
        )
    print(f"prepared {len(list(output.glob('*.json')))} path-fix configs")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
