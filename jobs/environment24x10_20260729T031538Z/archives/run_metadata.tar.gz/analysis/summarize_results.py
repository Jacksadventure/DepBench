#!/usr/bin/env python3

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIGS = [
    "claude_code__claude48",
    "claude_code__gemini35flash",
    "claude_code__gpt55",
    "codex__gpt55",
    "copilot_cli__claude48",
    "copilot_cli__gemini35flash",
    "copilot_cli__gpt55",
    "opencode__claude48",
    "opencode__gemini35flash",
    "opencode__gpt55",
]
EXPECTED_TASKS = {
    line.strip()
    for line in (ROOT / "manifests" / "affected_tasks_24.txt").read_text().splitlines()
    if line.strip()
}
RETRYABLE_EXCEPTIONS = {
    "AgentSetupTimeoutError",
    "NonZeroAgentExitCodeError",
}


def reward(result):
    verifier_result = result.get("verifier_result") or {}
    rewards = verifier_result.get("rewards") or {}
    observed = rewards.get("reward")
    return (1 if observed == 1 else 0, observed is not None)


def load_trials(config, jobs_directory):
    records = []
    for path in sorted(
        (ROOT / jobs_directory / config).glob("*/*/result.json")
    ):
        data = json.loads(path.read_text())
        task = (data.get("task_name") or "").rsplit("/", 1)[-1]
        if not task:
            continue
        reward_value, reward_available = reward(data)
        records.append(
            {
                "config": config,
                "task": task,
                "reward": reward_value,
                "reward_available": reward_available,
                "exception_type": (data.get("exception_info") or {}).get(
                    "exception_type"
                ),
                "started_at": data.get("started_at"),
                "finished_at": data.get("finished_at"),
                "path": str(path.relative_to(ROOT)),
                "source": jobs_directory,
            }
        )
    return records


def main():
    retry_manifest = json.loads(
        (ROOT / "manifests" / "infra_retry_cells.json").read_text(
            encoding="utf-8"
        )
    )
    manifest_rows = retry_manifest["cells"]
    expected_retry_cells = {
        (row["configuration"], row["task"])
        for row in manifest_rows
    }
    replaced_result_paths = set()
    for row in manifest_rows:
        relative = Path(row["replaced_result"])
        result_path = ROOT / relative
        if (
            relative.is_absolute()
            or ".." in relative.parts
            or len(relative.parts) != 5
            or relative.parts[0] != "harbor_jobs_path_fix"
            or relative.parts[1] != row["configuration"]
            or relative.name != "result.json"
            or not result_path.is_file()
        ):
            raise RuntimeError(
                f"missing or invalid replaced setup-timeout result: {relative}"
            )
        result = json.loads(result_path.read_text(encoding="utf-8"))
        task = (result.get("task_name") or "").rsplit("/", 1)[-1]
        exception_type = (result.get("exception_info") or {}).get(
            "exception_type"
        )
        if (
            task != row["task"]
            or exception_type != row["exception_type"]
            or exception_type not in RETRYABLE_EXCEPTIONS
        ):
            raise RuntimeError(
                f"replaced setup-timeout provenance mismatch: {relative}"
            )
        replaced_result_paths.add(str(relative))
    records = []
    all_records = []
    by_config = {}
    for config in CONFIGS:
        original = load_trials(config, "harbor_jobs")
        replacements = load_trials(config, "harbor_jobs_path_fix")
        retries = load_trials(config, "harbor_jobs_path_fix_retries")
        for source_rows, label in (
            (original, "original"),
            (replacements, "path-fix replacement"),
        ):
            source_tasks = [record["task"] for record in source_rows]
            if len(source_tasks) != len(set(source_tasks)):
                raise RuntimeError(
                    f"{config}: duplicate tasks in {label} results"
                )
        if {
            record["task"] for record in replacements
        } - EXPECTED_TASKS:
            raise RuntimeError(
                f"{config}: path-fix replacement contains an unexpected task"
            )
        retry_by_task = {}
        for record in retries:
            retry_by_task.setdefault(record["task"], []).append(record)
        expected_retry_tasks = {
            task
            for configuration, task in expected_retry_cells
            if configuration == config
        }
        if set(retry_by_task) != expected_retry_tasks:
            raise RuntimeError(
                f"{config}: infrastructure retry coverage mismatch: "
                f"{sorted(set(retry_by_task) ^ expected_retry_tasks)}"
            )
        selected_retries = {}
        for task, candidates in retry_by_task.items():
            valid = [
                record for record in candidates if record["reward_available"]
            ]
            if not valid:
                raise RuntimeError(
                    f"{config}/{task}: no infrastructure retry reached "
                    "the verifier"
                )
            selected_retries[task] = max(
                valid,
                key=lambda record: (
                    record["started_at"] or "",
                    record["path"],
                ),
            )
        selected_by_task = {record["task"]: record for record in original}
        selected_by_task.update(
            {record["task"]: record for record in replacements}
        )
        selected_by_task.update(selected_retries)
        selected = list(selected_by_task.values())
        tasks = {record["task"] for record in selected}
        if len(selected) != 24 or tasks != EXPECTED_TASKS:
            raise RuntimeError(
                f"{config}: expected 24 unique tasks, found {len(selected)} "
                f"records and task delta {sorted(tasks ^ EXPECTED_TASKS)}"
            )
        if any(
            record["source"] == "harbor_jobs" for record in selected
        ):
            raise RuntimeError(
                f"{config}: corrected full run does not cover all 24 tasks"
            )
        if any(not record["reward_available"] for record in selected):
            raise RuntimeError(
                f"{config}: a selected final trial did not reach the verifier"
            )
        records.extend(selected)
        all_records.extend(original)
        all_records.extend(replacements)
        all_records.extend(retries)
        exceptions = Counter(
            record["exception_type"] or "none" for record in selected
        )
        passes = sum(record["reward"] for record in selected)
        by_config[config] = {
            "trials": len(selected),
            "pass": passes,
            "non_pass": len(selected) - passes,
            "replacement_trials": len(replacements),
            "infrastructure_retry_trials": len(retries),
            "selected_infrastructure_retry_trials": len(selected_retries),
            "exceptions": dict(sorted(exceptions.items())),
        }

    all_record_paths = {record["path"] for record in all_records}
    if not replaced_result_paths <= all_record_paths:
        raise RuntimeError(
            "raw trial inventory dropped a replaced setup-timeout result"
        )

    output = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "affected_task_count": len(EXPECTED_TASKS),
        "config_count": len(CONFIGS),
        "expected_trials": len(EXPECTED_TASKS) * len(CONFIGS),
        "trials": len(records),
        "raw_trials": len(all_records),
        "replacement_trials": len(all_records) - len(records),
        "pass": sum(record["reward"] for record in records),
        "non_pass": len(records) - sum(record["reward"] for record in records),
        "by_config": by_config,
    }
    (ROOT / "analysis" / "final_summary.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )

    with (ROOT / "analysis" / "final_trials.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(sorted(records, key=lambda row: (row["config"], row["task"])))

    with (ROOT / "analysis" / "all_trials.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_records[0]))
        writer.writeheader()
        writer.writerows(
            sorted(
                all_records,
                key=lambda row: (
                    row["config"],
                    row["task"],
                    row["source"],
                ),
            )
        )

    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
