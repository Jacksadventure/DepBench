#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mapfile -t configs < <(
  find "$root/configs_path_fix" -maxdepth 1 -type f -name '*.json' \
    -printf '%f\n' | sort
)
max_active=5

run_config() {
  local file="$1"
  local name="${file%.json}"
  local log="$root/launcher_logs_path_fix/$name.log"
  local status="$root/launcher_logs_path_fix/$name.status"

  printf 'started_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$status"
  if PYTHONPATH="$root${PYTHONPATH:+:$PYTHONPATH}" \
    harbor run --config "$root/configs_path_fix/$file" --yes \
      > "$log" 2>&1; then
    printf 'exit_code=0\nfinished_at=%s\n' \
      "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
  else
    local code=$?
    printf 'exit_code=%s\nfinished_at=%s\n' \
      "$code" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
    return "$code"
  fi
}

declare -A names_by_pid=()
failures=0

wait_one() {
  local finished_pid
  if wait -n -p finished_pid "${!names_by_pid[@]}"; then
    printf 'completed %s\n' "${names_by_pid[$finished_pid]}"
  else
    printf 'failed %s\n' "${names_by_pid[$finished_pid]}" >&2
    failures=$((failures + 1))
  fi
  unset 'names_by_pid[$finished_pid]'
}

for file in "${configs[@]}"; do
  while ((${#names_by_pid[@]} >= max_active)); do
    wait_one
  done

  run_config "$file" &
  names_by_pid["$!"]="${file%.json}"
  printf 'launched %s\n' "${file%.json}"
done

while ((${#names_by_pid[@]})); do
  wait_one
done

if ((failures > 0)); then
  printf '%s configuration(s) failed\n' "$failures" >&2
  exit 1
fi
