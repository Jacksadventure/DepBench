# DepBench environment-repair rerun

- Created: 2026-07-29 03:15:38 UTC
- Release source: `main@7795c885d2579a2dff9e672208bcf9aef26338fb`
- Task source: `v4-with-test@c99664f7750c925c5de9d1e5718369dbeb2e21c7`
- Frozen dataset: `dataset/tasks/` (203 tasks)
- Selected tasks: `manifests/affected_tasks_24.txt` (24 tasks)
- Configurations: `configs/` (10 model x harness combinations)
- Planned formal trials: 240
- Per-configuration concurrency: 4
- Scheduler cap: 5 active configurations / 20 active trials
- Preflight jobs: `harbor_jobs/<configuration>/`
- Corrected full jobs: `harbor_jobs_path_fix/<configuration>/`
- Infrastructure retries: `harbor_jobs_path_fix_retries/<configuration>/`
- Launcher logs: `launcher_logs*/`

This rerun covers only the 24 tasks affected by Cargo, Java/Maven, or Go
login-shell environment preservation, including the otel-tui X11 image
repair. Test-contract repairs are excluded from this cohort.

The task snapshot, custom agents, configs, task images, and source metadata are
checksummed under `manifests/`. The runtime endpoint bindings are unchanged
from the prior formal 56 x 10 rerun.

The preflight run is retained as raw provenance but is not selected for final
outcomes. The corrected full run replaces all 240 cells. Trials that fail
before agent startup may be rerun with a longer setup timeout and at most four
concurrent trials; those retries replace only the exact
configuration-by-task cell while the original setup failure remains in the
packaged raw jobs.

When an infrastructure-retry attempt reaches the verifier for all but a
subset of its cells, later attempts are restricted to that missing subset.
`manifests/infra_retry_attempt_overrides.json` records the narrowed scope and
reason; successful raw trials from the earlier attempt remain unchanged.
The same manifest records one runtime cleanup where a timed-out agent process
survived after verifier startup and held the Cargo lock. Only that stale agent
process tree was terminated; the verifier continued without being restarted.

The first five corrected configurations retained the original 360-second
agent setup timeout. Before the second five configurations started, their
setup-only timeout was raised to 900 seconds after concurrent CLI installation
repeatedly exceeded 360 seconds. Agent execution timeouts, model settings,
task inputs, and verifier contracts were unchanged.
