#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DOCKER_HOST="${DOCKER_HOST:-unix:///run/user/1900/docker.sock}"

config="$root/configs_retries_supplemental2/claude_code__gemini35flash.json"
log="$root/launcher_logs_retries_supplemental2/claude_code__gemini35flash.log"
status="$root/launcher_logs_retries_supplemental2/claude_code__gemini35flash.status"
mkdir -p "$root/launcher_logs_retries_supplemental2"

printf 'started_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$status"
if PYTHONPATH="$root${PYTHONPATH:+:$PYTHONPATH}" \
  harbor run --config "$config" --yes > "$log" 2>&1; then
  printf 'exit_code=0\nfinished_at=%s\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
else
  code=$?
  printf 'exit_code=%s\nfinished_at=%s\n' \
    "$code" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
  exit "$code"
fi
