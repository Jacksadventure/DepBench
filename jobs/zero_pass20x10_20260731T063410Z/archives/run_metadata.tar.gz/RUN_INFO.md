# DepBench zero-pass contract-repair rerun

- Created: 2026-07-31 06:34:10 UTC
- Canonical task content: `9750bc95f5d0830059346fb1b3f6c947e40cb7d9`
- Frozen release worktree: `2b194cf42510db710e8bc506da05b143e4543d8e`
- Frozen dataset: `dataset/tasks/` (203 tasks)
- Selected tasks: `manifests/affected_tasks_20.txt` (20 tasks)
- Configurations: `configs/` (10 model x harness combinations)
- Planned formal trials: 200
- Per-configuration concurrency: 4
- Scheduler cap: 3 active configurations / 12 active trials
- Agent setup timeout: 900 seconds
- Jobs: `harbor_jobs/<configuration>/`
- Infrastructure retries: `harbor_jobs_retries/<configuration>/`

This rerun covers the 20 task-specific repairs validated by the
2026-07-31 zero-pass contract audit. The frozen tasks are byte-identical to
the canonical release snapshot after excluding generated Python bytecode.

The model, harness, web-tool policy, custom agent implementation, agent
execution timeout, and verifier timeout are unchanged from the prior formal
10-configuration run. Only the selected task cohort, output directory, and
agent setup timeout differ.

Missing verifier rewards caused before agent execution or verification are
eligible for exact-cell infrastructure retries. Completed verifier outcomes
and agent execution timeouts are not retried.
