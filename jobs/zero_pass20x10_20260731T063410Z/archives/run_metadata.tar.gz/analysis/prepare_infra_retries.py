#!/usr/bin/env python3

import copy
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIGS = sorted(path.stem for path in (ROOT / "configs").glob("*.json"))
LOW_CONCURRENCY_CONFIGS = {
    "claude_code__gemini35flash",
    "claude_code__gpt55",
}
TASKS = {
    line.strip()
    for line in (
        ROOT / "manifests" / "affected_tasks_20.txt"
    ).read_text(encoding="utf-8").splitlines()
    if line.strip()
}
DISK_FAILURE = re.compile(
    r"no space left on device|failure writing output|"
    r"wrote only \d+ of|unable to write file|disk quota exceeded|\benospc\b",
    re.IGNORECASE,
)
DISK_EVIDENCE_FILES = (
    "result.json",
    "exception.txt",
    "trial.log",
    "agent/claude-code.txt",
    "agent/codex.txt",
    "agent/copilot-cli.txt",
    "agent/copilot-cli.jsonl",
    "agent/opencode.txt",
    "verifier/test-stdout.txt",
)


def infer_task(trial_name):
    candidate = trial_name.rsplit("__", 1)[0]
    if candidate in TASKS:
        return candidate
    matches = [
        task
        for task in TASKS
        if task.startswith(candidate) or candidate.startswith(task)
    ]
    if len(matches) != 1:
        raise RuntimeError(
            f"cannot infer task from malformed trial {trial_name}: {matches}"
        )
    return matches[0]


def load_main_results(configuration):
    rows = {}
    pattern = ROOT / "harbor_jobs" / configuration
    for result_path in sorted(pattern.glob("*/*/result.json")):
        try:
            result = json.loads(result_path.read_text(encoding="utf-8"))
            task = (result.get("task_name") or "").rsplit("/", 1)[-1]
            if not task:
                raise RuntimeError(f"missing task_name in {result_path}")
            rewards = (
                (result.get("verifier_result") or {}).get("rewards") or {}
            )
            reward = rewards.get("reward")
            exception = result.get("exception_info") or {}
            exception_type = (
                exception.get("exception_type")
                or exception.get("type")
                or ""
            )
        except json.JSONDecodeError:
            task = infer_task(result_path.parent.name)
            reward = None
            exception_type = "MalformedResult"
        if task in rows:
            raise RuntimeError(
                f"duplicate main result for {configuration}/{task}"
            )
        rows[task] = {
            "reward": reward,
            "exception_type": exception_type,
            "path": str(result_path.relative_to(ROOT)),
            "disk_contaminated": any(
                DISK_FAILURE.search(
                    evidence.read_text(
                        encoding="utf-8", errors="replace"
                    )
                )
                for relative in DISK_EVIDENCE_FILES
                if (evidence := result_path.parent / relative).is_file()
            ),
        }
    return rows


def main():
    retry_cells = []
    retry_tasks = {}
    supplemental_tasks = {}
    timeout_supplemental_tasks = {}
    for configuration in CONFIGS:
        rows = load_main_results(configuration)
        tasks = []
        supplemental = []
        timeout_supplemental = []
        for task in sorted(TASKS):
            row = rows.get(task)
            if row is None:
                retry_cells.append(
                    {
                        "configuration": configuration,
                        "task": task,
                        "reason": "unrun",
                        "replaced_result": "",
                        "retry_phase": "base",
                    }
                )
                tasks.append(task)
            elif (
                row["reward"] is None
                and row["exception_type"] != "AgentTimeoutError"
            ):
                retry_cells.append(
                    {
                        "configuration": configuration,
                        "task": task,
                        "reason": row["exception_type"],
                        "replaced_result": row["path"],
                        "retry_phase": "base",
                    }
                )
                tasks.append(task)
            elif row["reward"] == 0 and row["disk_contaminated"]:
                retry_cells.append(
                    {
                        "configuration": configuration,
                        "task": task,
                        "reason": "disk-contaminated-reward-zero",
                        "replaced_result": row["path"],
                        "retry_phase": "supplemental",
                    }
                )
                supplemental.append(task)
            elif (
                row["reward"] is None
                and row["exception_type"] == "AgentTimeoutError"
                and row["disk_contaminated"]
            ):
                retry_cells.append(
                    {
                        "configuration": configuration,
                        "task": task,
                        "reason": "disk-contaminated-agent-timeout",
                        "replaced_result": row["path"],
                        "retry_phase": "supplemental2",
                    }
                )
                timeout_supplemental.append(task)
        if tasks:
            retry_tasks[configuration] = tasks
        if supplemental:
            supplemental_tasks[configuration] = supplemental
        if timeout_supplemental:
            timeout_supplemental_tasks[configuration] = timeout_supplemental

    if len(retry_cells) != 88:
        raise RuntimeError(
            f"expected 88 infrastructure retry cells, got {len(retry_cells)}"
        )

    retry_manifest = {
        "reason": (
            "Exact-cell replacement for unrun, rewardless, or explicitly "
            "disk-contaminated reward-zero failures."
        ),
        "cells": retry_cells,
    }
    (ROOT / "manifests" / "infra_retry_cells.json").write_text(
        json.dumps(retry_manifest, indent=2) + "\n",
        encoding="utf-8",
    )

    output_dir = ROOT / "configs_retries"
    output_dir.mkdir(exist_ok=True)
    for stale in output_dir.glob("*.json"):
        stale.unlink()
    for configuration, tasks in sorted(retry_tasks.items()):
        source = json.loads(
            (ROOT / "configs" / f"{configuration}.json").read_text(
                encoding="utf-8"
            )
        )
        config = copy.deepcopy(source)
        config["datasets"][0]["task_names"] = tasks
        config["jobs_dir"] = str(
            ROOT / "harbor_jobs_retries" / configuration
        )
        config["n_concurrent_trials"] = (
            2 if configuration in LOW_CONCURRENCY_CONFIGS else 3
        )
        config["agents"][0]["override_setup_timeout_sec"] = 1200
        (output_dir / f"{configuration}.json").write_text(
            json.dumps(config, indent=2) + "\n",
            encoding="utf-8",
        )

    supplemental_dir = ROOT / "configs_retries_supplemental"
    supplemental_dir.mkdir(exist_ok=True)
    for stale in supplemental_dir.glob("*.json"):
        stale.unlink()
    for configuration, tasks in sorted(supplemental_tasks.items()):
        source = json.loads(
            (ROOT / "configs" / f"{configuration}.json").read_text(
                encoding="utf-8"
            )
        )
        config = copy.deepcopy(source)
        config["datasets"][0]["task_names"] = tasks
        config["jobs_dir"] = str(
            ROOT / "harbor_jobs_retries" / configuration
        )
        config["n_concurrent_trials"] = 2
        config["agents"][0]["override_setup_timeout_sec"] = 1200
        (supplemental_dir / f"{configuration}.json").write_text(
            json.dumps(config, indent=2) + "\n",
            encoding="utf-8",
        )

    timeout_supplemental_dir = ROOT / "configs_retries_supplemental2"
    timeout_supplemental_dir.mkdir(exist_ok=True)
    for stale in timeout_supplemental_dir.glob("*.json"):
        stale.unlink()
    for configuration, tasks in sorted(
        timeout_supplemental_tasks.items()
    ):
        source = json.loads(
            (ROOT / "configs" / f"{configuration}.json").read_text(
                encoding="utf-8"
            )
        )
        config = copy.deepcopy(source)
        config["datasets"][0]["task_names"] = tasks
        config["jobs_dir"] = str(
            ROOT / "harbor_jobs_retries" / configuration
        )
        config["n_concurrent_trials"] = 1
        config["agents"][0]["override_setup_timeout_sec"] = 1200
        (
            timeout_supplemental_dir / f"{configuration}.json"
        ).write_text(
            json.dumps(config, indent=2) + "\n",
            encoding="utf-8",
        )

    print(
        json.dumps(
            {
                "retry_cells": len(retry_cells),
                "base_configurations": {
                    configuration: len(tasks)
                    for configuration, tasks in sorted(retry_tasks.items())
                },
                "supplemental_configurations": {
                    configuration: len(tasks)
                    for configuration, tasks in sorted(
                        supplemental_tasks.items()
                    )
                },
                "timeout_supplemental_configurations": {
                    configuration: len(tasks)
                    for configuration, tasks in sorted(
                        timeout_supplemental_tasks.items()
                    )
                },
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
