#!/usr/bin/env python3

import json
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
rows = []
for path in ROOT.glob("harbor_jobs/*/*/*/result.json"):
    try:
        result = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        continue
    reward = ((result.get("verifier_result") or {}).get("rewards") or {}).get(
        "reward"
    )
    rows.append(
        (
            path.parts[-4],
            (result.get("task_name") or "").rsplit("/", 1)[-1],
            reward,
            (result.get("exception_info") or {}).get("exception_type"),
        )
    )

print(f"completed={len(rows)}/200 pass={sum(row[2] == 1 for row in rows)}")
for config in sorted({row[0] for row in rows}):
    subset = [row for row in rows if row[0] == config]
    exceptions = Counter(row[3] or "none" for row in subset)
    missing = sum(row[2] is None for row in subset)
    print(
        f"{config}: {len(subset)}/20 pass={sum(row[2] == 1 for row in subset)} "
        f"missing_reward={missing} exceptions={dict(exceptions)}"
    )
