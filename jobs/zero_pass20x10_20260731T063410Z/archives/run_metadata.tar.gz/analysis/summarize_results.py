#!/usr/bin/env python3

import csv
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIGS = [
    "claude_code__claude48",
    "claude_code__gemini35flash",
    "claude_code__gpt55",
    "codex__gpt55",
    "copilot_cli__claude48",
    "copilot_cli__gemini35flash",
    "copilot_cli__gpt55",
    "opencode__claude48",
    "opencode__gemini35flash",
    "opencode__gpt55",
]
EXPECTED_TASKS = {
    line.strip()
    for line in (ROOT / "manifests" / "affected_tasks_20.txt").read_text().splitlines()
    if line.strip()
}
DISK_FAILURE = re.compile(
    r"no space left on device|failure writing output|"
    r"wrote only \d+ of|unable to write file|disk quota exceeded|\benospc\b",
    re.IGNORECASE,
)
DISK_EVIDENCE_FILES = (
    "result.json",
    "exception.txt",
    "trial.log",
    "agent/claude-code.txt",
    "agent/codex.txt",
    "agent/copilot-cli.txt",
    "agent/copilot-cli.jsonl",
    "agent/opencode.txt",
    "verifier/test-stdout.txt",
)


def infer_task(trial_name):
    candidate = trial_name.rsplit("__", 1)[0]
    if candidate in EXPECTED_TASKS:
        return candidate
    matches = [
        task
        for task in EXPECTED_TASKS
        if task.startswith(candidate) or candidate.startswith(task)
    ]
    if len(matches) != 1:
        raise RuntimeError(
            f"cannot infer task from malformed trial {trial_name}: {matches}"
        )
    return matches[0]


def reward(result):
    rewards = ((result.get("verifier_result") or {}).get("rewards") or {})
    observed = rewards.get("reward")
    return (1 if observed == 1 else 0, observed is not None)


def load_trials(config, directory):
    records = []
    for path in sorted((ROOT / directory / config).glob("*/*/result.json")):
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError:
            records.append(
                {
                    "config": config,
                    "task": infer_task(path.parent.name),
                    "reward": 0,
                    "reward_available": False,
                    "exception_type": "MalformedResult",
                    "started_at": "",
                    "finished_at": "",
                    "path": str(path.relative_to(ROOT)),
                    "source": directory,
                }
            )
            continue
        task = (data.get("task_name") or "").rsplit("/", 1)[-1]
        if not task:
            continue
        value, available = reward(data)
        records.append(
            {
                "config": config,
                "task": task,
                "reward": value,
                "reward_available": available,
                "exception_type": (data.get("exception_info") or {}).get(
                    "exception_type"
                ),
                "started_at": data.get("started_at"),
                "finished_at": data.get("finished_at"),
                "path": str(path.relative_to(ROOT)),
                "source": directory,
            }
        )
    return records


def disk_contaminated(row):
    trial_dir = (ROOT / row["path"]).parent
    for relative in DISK_EVIDENCE_FILES:
        path = trial_dir / relative
        if not path.is_file():
            continue
        if DISK_FAILURE.search(
            path.read_text(encoding="utf-8", errors="replace")
        ):
            return True
    return False


def main():
    retry_path = ROOT / "manifests" / "infra_retry_cells.json"
    retry_cells = set()
    if retry_path.exists():
        retry_cells = {
            (row["configuration"], row["task"])
            for row in json.loads(retry_path.read_text())["cells"]
        }

    selected = []
    all_records = []
    by_config = {}
    for config in CONFIGS:
        main_rows = load_trials(config, "harbor_jobs")
        retry_rows = load_trials(config, "harbor_jobs_retries")
        all_records.extend(main_rows)
        all_records.extend(retry_rows)

        by_task = {}
        for row in main_rows:
            if row["task"] in by_task:
                raise RuntimeError(f"{config}: duplicate main task {row['task']}")
            by_task[row["task"]] = row

        retries_by_task = {}
        for row in retry_rows:
            retries_by_task.setdefault(row["task"], []).append(row)
        expected_retries = {
            task for configuration, task in retry_cells if configuration == config
        }
        if set(retries_by_task) != expected_retries:
            raise RuntimeError(
                f"{config}: retry coverage mismatch "
                f"{sorted(set(retries_by_task) ^ expected_retries)}"
            )
        for task, rows in retries_by_task.items():
            valid_rows = [
                row
                for row in rows
                if row["reward_available"]
                or row["exception_type"] == "AgentTimeoutError"
            ]
            if not valid_rows:
                raise RuntimeError(
                    f"{config}/{task}: retry has no verifier reward or "
                    "agent timeout"
                )
            by_task[task] = max(
                valid_rows,
                key=lambda row: (row["started_at"] or "", row["path"]),
            )

        tasks = set(by_task)
        if tasks != EXPECTED_TASKS or len(by_task) != 20:
            raise RuntimeError(
                f"{config}: expected 20 tasks; delta "
                f"{sorted(tasks ^ EXPECTED_TASKS)}"
            )
        invalid_missing_rewards = [
            row["task"]
            for row in by_task.values()
            if not row["reward_available"]
            and row["exception_type"] != "AgentTimeoutError"
        ]
        if invalid_missing_rewards:
            raise RuntimeError(
                f"{config}: unexplained trials without verifier rewards: "
                f"{invalid_missing_rewards}"
            )
        contaminated = [
            row["task"] for row in by_task.values() if disk_contaminated(row)
        ]
        if contaminated:
            raise RuntimeError(
                f"{config}: selected trials retain disk-failure evidence: "
                f"{contaminated}"
            )

        rows = list(by_task.values())
        selected.extend(rows)
        passes = sum(row["reward"] for row in rows)
        by_config[config] = {
            "trials": len(rows),
            "pass": passes,
            "non_pass": len(rows) - passes,
            "exceptions": dict(
                sorted(Counter(row["exception_type"] or "none" for row in rows).items())
            ),
        }

    output = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "affected_task_count": len(EXPECTED_TASKS),
        "config_count": len(CONFIGS),
        "expected_trials": 200,
        "trials": len(selected),
        "raw_trials": len(all_records),
        "pass": sum(row["reward"] for row in selected),
        "non_pass": len(selected) - sum(row["reward"] for row in selected),
        "by_config": by_config,
    }
    (ROOT / "analysis" / "final_summary.json").write_text(
        json.dumps(output, indent=2) + "\n"
    )
    for name, rows in (
        ("final_trials.csv", selected),
        ("all_trials.csv", all_records),
    ):
        with (ROOT / "analysis" / name).open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(
                sorted(
                    rows,
                    key=lambda row: (
                        row["config"],
                        row["task"],
                        row["source"],
                        row["started_at"] or "",
                    ),
                )
            )
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
