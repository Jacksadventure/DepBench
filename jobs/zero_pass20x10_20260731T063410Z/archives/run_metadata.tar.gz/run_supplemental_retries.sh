#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DOCKER_HOST="${DOCKER_HOST:-unix:///run/user/1900/docker.sock}"

mkdir -p \
  "$root/launcher_logs_retries_supplemental" \
  "$root/harbor_jobs_retries"

declare -A names_by_pid=()
failures=0

for config in "$root"/configs_retries_supplemental/*.json; do
  name="$(basename "${config%.json}")"
  log="$root/launcher_logs_retries_supplemental/$name.log"
  status="$root/launcher_logs_retries_supplemental/$name.status"
  (
    printf 'started_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$status"
    if PYTHONPATH="$root${PYTHONPATH:+:$PYTHONPATH}" \
      harbor run --config "$config" --yes > "$log" 2>&1; then
      printf 'exit_code=0\nfinished_at=%s\n' \
        "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
    else
      code=$?
      printf 'exit_code=%s\nfinished_at=%s\n' \
        "$code" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$status"
      exit "$code"
    fi
  ) &
  names_by_pid["$!"]="$name"
  printf 'launched supplemental %s\n' "$name"
done

for pid in "${!names_by_pid[@]}"; do
  if wait "$pid"; then
    printf 'completed supplemental %s\n' "${names_by_pid[$pid]}"
  else
    printf 'failed supplemental %s\n' "${names_by_pid[$pid]}" >&2
    failures=$((failures + 1))
  fi
done

if ((failures > 0)); then
  exit 1
fi
